package br.com.ovideomvp.ovideo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.ovideomvp.ovideo.domain.Artista;
import br.com.ovideomvp.ovideo.repository.ArtistaRepository;

@Service
public class ArtistaService extends GenericService<Artista>{

	@Autowired
	ArtistaRepository repo;
	
	@Autowired
	public ArtistaService(ArtistaRepository repo) {
		super(repo);
		// TODO Auto-generated constructor stub
	}


	public List<Artista> search(String text){
		return repo.findByNomeArtistaContainingIgnoreCase(text);
	}

}
