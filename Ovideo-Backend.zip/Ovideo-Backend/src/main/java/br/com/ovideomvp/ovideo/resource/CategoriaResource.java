package br.com.ovideomvp.ovideo.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.ovideomvp.ovideo.domain.Categoria;
import br.com.ovideomvp.ovideo.dto.CategoriaDTO;
import br.com.ovideomvp.ovideo.repository.CategoriaRepository;
import br.com.ovideomvp.ovideo.service.CategoriaService;
import io.swagger.annotations.ApiOperation;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/categorias")
public class CategoriaResource extends GenericResource{

	@Autowired
	CategoriaService service;
	
	@Autowired
	CategoriaRepository repo;
	
	@PostMapping("/criar")
	@ApiOperation(value = "Cadastro de Categoria")
	public ResponseEntity<Categoria> criar(@RequestBody CategoriaDTO objDto ) {
		
		if(repo.findByNomeIgnoreCase(objDto.getNome()) != null) {
			return retornarNaoAlterado();
			
		}else {
			try {
				Categoria obj = new Categoria();
				obj = obj.mapear(objDto);
				service.save(obj);
				return retornarCriado(obj);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
			return retornarErro(null);

	}
	
	@GetMapping()
	@ApiOperation(value="Listar Categorias")
	public ResponseEntity<List<Categoria>> listar(){
		return retornarSucesso(service.findAll());
	}
	
	@DeleteMapping("/delete")
	@ApiOperation(value="Deletar Categoria")
	public ResponseEntity<Categoria> delete(@RequestParam String nome){
		
		Categoria cat = repo.findByNomeIgnoreCase(nome);
		if(cat != null) {
			service.delete(cat.getId());
			return retornarSucesso(null);
		}else {
			return retornarNaoEncontrado();
		}
	
	} 
	
	
}









