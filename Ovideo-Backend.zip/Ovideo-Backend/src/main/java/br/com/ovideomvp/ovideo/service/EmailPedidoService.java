package br.com.ovideomvp.ovideo.service;

import javax.mail.internet.MimeMessage;

import org.springframework.mail.SimpleMailMessage;

import br.com.ovideomvp.ovideo.domain.Pedido;

public interface EmailPedidoService <T>{
void sendEmail(SimpleMailMessage msg);
	
	
	void sendHtmlEmail(MimeMessage msg);

	void sendConfirmacaoPedido(T obj);

	void sendOrderConfirmationHtmlEmail(T obj);


	void sendOrderConfirmationHtmlEmailEntregaPedido(Pedido obj);
}
