package br.com.ovideomvp.ovideo.service;

import java.util.Date;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import br.com.ovideomvp.ovideo.domain.Artista;

public abstract class AbstractEmailServiceArtista implements EmailService<Artista> {
	
	@Value("${default.sender}")
	private String sender;
	
	@Autowired
	private TemplateEngine templateEngine;
	
	@Autowired
	private JavaMailSender javaMailSender;
	
	//NÃO USAR
	@Override
	public void sendConfirmacaoPedido(Artista obj) {
		SimpleMailMessage sm = prepareSimpleMailMessageFromPedido(obj);
		sendEmail(sm);
	}
	
	//NAO USAR
	protected SimpleMailMessage prepareSimpleMailMessageFromPedido(Artista obj) {
		SimpleMailMessage sm = new SimpleMailMessage();
		sm.setTo(obj.getEmail());
		sm.setFrom(sender);
		sm.setSubject("Pedido confirmado! Código: " + obj.getId());
		sm.setSentDate(new Date(System.currentTimeMillis()));
		sm.setText(obj.toString());
		return sm;
	}
	
	protected String htmlFromTemplateCadastro(Artista obj) {
		Context context = new Context();
		context.setVariable("artista", obj);
		return templateEngine.process("email/cadastro-artista", context);
	}
	
	@Override
	public void sendOrderConfirmationHtmlEmail(Artista obj) {
		try {
			MimeMessage mm = prepareMimeMessageFromPedido(obj);
			sendHtmlEmail(mm);
		}
		catch (MessagingException e) {
			sendConfirmacaoPedido(obj);
		}
	}

	protected MimeMessage prepareMimeMessageFromPedido(Artista obj) throws MessagingException {
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		MimeMessageHelper mmh = new MimeMessageHelper(mimeMessage, true);
		mmh.setTo(obj.getEmail());
		mmh.setFrom(sender);
		mmh.setSubject("Ovideo: Complete Seu Cadastro!");
		mmh.setSentDate(new Date(System.currentTimeMillis()));
		mmh.setText(htmlFromTemplateCadastro(obj), true);
		return mimeMessage;
	}
}
