package br.com.ovideomvp.ovideo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

import br.com.ovideomvp.ovideo.service.EmailPedidoService;
import br.com.ovideomvp.ovideo.service.EmailService;
import br.com.ovideomvp.ovideo.service.SmtpEmailServiceArtista;
import br.com.ovideomvp.ovideo.service.SmtpEmailServicePedido;

@Configuration
@Profile("prod")
public class ProdConfig {
	
	
	@Bean
	public EmailService emailService() {
		return new SmtpEmailServiceArtista();
	}
	
	@Bean
	public EmailPedidoService emailPedidoService() {
		return new SmtpEmailServicePedido();
	}
}
