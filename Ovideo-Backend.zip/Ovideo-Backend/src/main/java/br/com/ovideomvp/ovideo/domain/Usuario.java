package br.com.ovideomvp.ovideo.domain;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.com.ovideomvp.ovideo.domain.enums.Perfil;
import br.com.ovideomvp.ovideo.dto.UsuarioDTODetalhes;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Document(collection = "Usuario")
 @Getter @Setter @ToString @NoArgsConstructor
public class Usuario implements Serializable {
	private static final long serialVersionUID = -4680475697047507119L;

	@Id
	private String id;
	
	private String nome;

	private String email;

	@JsonIgnore
	private String senha;
	
	@JsonIgnore
	private String nrCartao;
	
	@JsonIgnore
	private Integer codSeguranca;
	
	private String urlFotoPerfil;
	
	private String celular;
	
	private Set<Integer> perfis = new HashSet<>();
	
	private List<String> urlVideo = new ArrayList<>();

	public Usuario(String id, String nome, String email, String senha, String nrCartao, Integer codSeguranca,
			String urlFotoPerfil, String celular, Set<Integer> perfis) {
		super();
		this.id = id;
		this.nome = nome;
		this.email = email;
		this.senha = senha;
		this.nrCartao = nrCartao;
		this.codSeguranca = codSeguranca;
		this.urlFotoPerfil = urlFotoPerfil;
		this.celular = celular;
		this.perfis = perfis;
	}

	public Usuario(String email, String senha) {
		super();
		this.email = email;
		this.senha = senha;
	}

	public Usuario(String senha, String nrCartao, Integer codSeguranca, String urlFotoPerfil, String celular) {
		super();
		this.senha = senha;
		this.nrCartao = nrCartao;
		this.codSeguranca = codSeguranca;
		this.urlFotoPerfil = urlFotoPerfil;
		this.celular = celular;
	}

	public void PreencherDetalhes(UsuarioDTODetalhes objDTO) {
		this.setCodSeguranca(objDTO.getCodSeguranca());
		this.setNrCartao(objDTO.getNrCartao());
		
		if(objDTO.getUrlFotoPerfil() != null)
			this.setUrlFotoPerfil(objDTO.getUrlFotoPerfil());
	
		if(objDTO.getCelular() != null)
			this.setCelular(objDTO.getCelular());
		
	}
	
	public void addPerfil(Perfil perfil) {
		perfis.add(perfil.getCod());
	
}
	public Set<Perfil> getPerfis() {
		return perfis.stream().map(x -> Perfil.toEnum(x)).collect(Collectors.toSet());
	}
	
	
}
