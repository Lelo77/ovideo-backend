//package br.com.ovideomvp.ovideo.resource;
//
//import java.net.MalformedURLException;
//import java.net.URI;
//import java.util.Collections;
//import java.util.List;
//import java.util.Optional;
//import java.util.stream.Collectors;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.data.domain.Pageable;
//import org.springframework.data.mongodb.core.MongoTemplate;
//import org.springframework.data.mongodb.core.query.Query;
//import org.springframework.http.ResponseEntity;
//import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
//import org.springframework.web.bind.annotation.DeleteMapping;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.PutMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.multipart.MultipartFile;
//
//import com.amazonaws.services.alexaforbusiness.model.Sort;
//import com.amazonaws.services.apigatewayv2.model.BadRequestException;
//
//import br.com.ovideomvp.ovideo.domain.Artista;
//import br.com.ovideomvp.ovideo.domain.Categoria;
//import br.com.ovideomvp.ovideo.dto.ArtistaDTO;
//import br.com.ovideomvp.ovideo.exceptions.FileException;
//import br.com.ovideomvp.ovideo.mappers.ArtistaMapper;
//import br.com.ovideomvp.ovideo.repository.ArtistaRepository;
//import br.com.ovideomvp.ovideo.service.ArtistaService;
//import br.com.ovideomvp.ovideo.service.CategoriaService;
//import br.com.ovideomvp.ovideo.service.EmailService;
//import io.swagger.annotations.Api;
//import io.swagger.annotations.ApiOperation;
//
//@RestController
//@RequestMapping("/artistas")
//@Api(value = "Artistas")
//public class ArtistaResource extends GenericResource {
//
//	@Autowired
//	BCryptPasswordEncoder pe;
//	
//	@Autowired
//	EmailService<Artista> emailService;
//	
//	@Autowired
//	ArtistaService service;
//
//	@Autowired
//	ArtistaRepository repo;
//	
//	@Autowired
//	CategoriaService categoriaService;
//	
//	@Autowired
//	ArtistaMapper mapper;
//
//	@PostMapping("/criar-artista-completo")
//	@ApiOperation(value = "Cadastro de Artista")
//	public ResponseEntity<Artista> criar(@RequestBody ArtistaDTO objDTO) {
//
//		if (repo.findByEmail(objDTO.getEmail()) == null) {
//			Categoria cat = categoriaService.findByNome(objDTO.getCategoriaArtista());
//			if(cat != null) {
//				Artista obj = mapper.mapear(objDTO);
//				Artista artistaResponse =  service.save(obj);
//				if(artistaResponse != null) {
//					cat.setQuantidade(cat.getQuantidade() + 1l);
//					categoriaService.save(cat);	
//					return retornarSucesso(artistaResponse);
//				}
//				
//				
//			}
//
//			return retornarErro(null);
//		}
//
//		return retornarNaoAlterado();
//	}
//
//	@PutMapping("/alterar")
//	public ResponseEntity<Artista> alterar(@RequestBody ArtistaDTO objDTO) {
//		
//		Artista obj = repo.findByEmail(objDTO.getEmail());
//			Artista result = obj;
//			result = result.mapear(objDTO);
//			System.out.println("+++++++++++++++="+result.getPerfis());
//			result.setSenha(pe.encode(objDTO.getSenha()));
//			return retornarSucesso(service.update(result, result.getId()));
//	}
//
//	@DeleteMapping("/delete")
//	public ResponseEntity<Artista> deletar(@RequestParam String nome, @RequestParam String categoria) {
//		Artista obj = repo.findByNomeArtistaAndCategoriaArtistaIgnoreCase(nome, categoria);
//
//		if (obj != null) {
//			Artista objClone = obj;
//			service.delete(obj.getId());
//			return retornarSucesso(objClone);
//
//		}
//		return retornarNaoEncontrado();
//
//	}
//
//	@GetMapping("/listar")
//	public ResponseEntity<List<ArtistaDTO>> listar() {
//		List<Artista> ls = service.findAll();
//
//		List<ArtistaDTO> lsDTO = ls.stream().map(item -> item.DTO()).collect(Collectors.toList());
//
//		return retornarSucesso(lsDTO);
//	}
//
//	@GetMapping("/")
//	public ResponseEntity<ArtistaDTO> buscar(@RequestParam("id") String id) {
//		Optional<Artista> obj = repo.findById(id);
//		if (obj.isPresent())
//			return retornarSucesso(obj.get().DTO());
//		return retornarNaoEncontrado();
//	}
//
//	@PostMapping(value = "/videoPrincipal")
//	public ResponseEntity<Void> uploadMainVideo(@RequestParam(name = "file") MultipartFile file,
//			@RequestParam(name = "email") String email) throws MalformedURLException {
//		URI uri;
//		try {
//			uri = service.uploadProfilePicture(file);
//			Artista artista = repo.findByEmail(email);
//			if (artista != null)
//				artista.setUrlVideoPrincipal(uri.toURL().toString());
//			service.update(artista, artista.getId());
//			return ResponseEntity.created(uri).build();
//		} catch (FileException e) {
//			new BadRequestException("Não foi possível fazer o upload do arquivo");
//			e.printStackTrace();
//		}
//		return null;
//	}
//
//	@PostMapping(value = "/imagemCard")
//	public ResponseEntity<Void> uploadImagemCard(@RequestParam(name = "file") MultipartFile file,
//			@RequestParam(name = "email") String email) throws MalformedURLException {
//		URI uri;
//		try {
//			uri = service.uploadProfilePicture(file);
//			Artista artista = repo.findByEmail(email);
//			if (artista != null)
//				artista.setUrlFotoCard(uri.toURL().toString());
//			service.update(artista, artista.getId());
//			return ResponseEntity.created(uri).build();
//		} catch (FileException e) {
//			new BadRequestException("Não foi possível fazer o upload do arquivo");
//			e.printStackTrace();
//		}
//		return null;
//	}
//	
//	@PostMapping(value = "/listaVideos")
//	public ResponseEntity<Void> uploadVideos(@RequestParam(name = "file") MultipartFile file,
//			@RequestParam(name = "email") String email) throws MalformedURLException {
//		URI uri;
//		try {
//			uri = service.uploadProfilePicture(file);
//			Artista artista = repo.findByEmail(email);
//			if (artista != null)
//				artista.getUrlVideos().add((uri.toURL().toString()));
//			service.update(artista, artista.getId());
//			return ResponseEntity.created(uri).build();
//		} catch (FileException e) {
//			new BadRequestException("Não foi possível fazer o upload do arquivo");
//			e.printStackTrace();
//		}
//		return null;
//	}
//	@GetMapping(value = "/nomeArtista")
//	public ResponseEntity<List<Artista>> getNome(@RequestParam(name="nomeArtista") String nome){
//		if(nome.length() > 3) {
//			List<Artista> lsArtistas = repo.findByNomeArtistaIgnoreCase(nome);
//			return retornarSucesso(lsArtistas);
//		}
//		return retornarSucesso(Collections.emptyList());
//	}
//	
//	@GetMapping(value = "/categoriaArtista")
//	public ResponseEntity<List<Artista>> getCategoria(@RequestParam(name="categoria") String categoria){
//			List<Artista> lsArtistas = repo.findByCategoriaArtistaIgnoreCase(categoria);
//			return retornarSucesso(lsArtistas);
//	}
//	
//	
////	public ResponseEntity<?> email(){
////		Artista a = repo.findByNomeArtistaAndCategoriaArtistaIgnoreCase("Rodrigo Yuri", "programador");
////		try {
////			email.sendOrderConfirmationHtmlEmail(a);
////			retornarSucesso(a);
////		} catch (Exception e) {
////			e.printStackTrace();
////			
////		} 
////		return retornarErro(a);
////	}
//
//	@PostMapping(value="/email")
//	public ResponseEntity<Artista> enviarSolicitacaoArtista(
//			@RequestParam(value="Nome") String nomeArtista,
//			@RequestParam(value="Categoria") String categoria,
//			@RequestParam(value="email") String email){
//		
//		if(repo.findByEmail(email) != null) {
//			return retornarNaoAlterado();
//		
//		}else {
//			Categoria cat =categoriaService.findByNome(categoria);
//			if(cat != null) {
//				Artista artista = new Artista(nomeArtista, cat.getNome(), email);		
//				cat.setQuantidade(cat.getQuantidade()+1);
//				categoriaService.updateCat(cat);
//				Artista response = service.save(artista);
//				try {
//					emailService.sendOrderConfirmationHtmlEmail(response);
//					return retornarCriado(response);
//				} catch (Exception e) {
//					e.printStackTrace();
//				}
//			}
//		
//			return retornarErro(null);
//		}
//		
//		
//		
//	}
//
//	@GetMapping("/search")
//	public ResponseEntity<List<Artista>> search(@RequestParam(value="text") String text){
//		if(text.length() >= 3)
//			return retornarSucesso(service.search(text));
//		return retornarSucesso(Collections.emptyList());
//	}
//	
//	public ResponseEntity<List<Artista>> sort(){
//		Query q = new Query();
//		MongoTemplate m = new MongoTemplate(null);
//		q.with((Pageable) new Sort());
//		List<Artista> ls = m.find(q, Artista.class);
//		
//		return retornarSucesso(ls);
//	}
//}
