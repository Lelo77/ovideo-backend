package br.com.ovideomvp.ovideo.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString @NoArgsConstructor
public class PedidoTableDTO implements Serializable {
	private static final long serialVersionUID = 4304813341496085002L;

	
	private String id;
	private String Solicitante;
	private String status;
	private String details;
	
	public PedidoTableDTO(String id, String solicitante, String status, String details) {
		super();
		this.id = id;
		Solicitante = solicitante;
		this.status = status;
		this.details = details;
	}
	
	
	
}
