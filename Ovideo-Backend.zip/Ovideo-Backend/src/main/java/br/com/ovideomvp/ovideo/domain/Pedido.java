package br.com.ovideomvp.ovideo.domain;

import java.io.Serializable;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Document(collection = "Pedido")
@Getter @Setter @ToString @NoArgsConstructor
public class Pedido implements Serializable {
	private static final long serialVersionUID = 2687578440718904821L;
	
	@Id
	private String id;
	private String idArtista;
	private String idUsuario;
	private String destinatario;
	private String conteudoVideo;
	private String dtPedido;
	private String status;
	private String urlFinalizarCompra;
	
	public Pedido(String id, String idArtista, String idUsuario, String destinatario, String conteudoVideo,
			String dtPedido, String status) {
		super();
		this.id = id;
		this.idArtista = idArtista;
		this.idUsuario = idUsuario;
		this.destinatario = destinatario;
		this.conteudoVideo = conteudoVideo;
		this.dtPedido = dtPedido;
		this.status = status;
	}
	
	
	
}
