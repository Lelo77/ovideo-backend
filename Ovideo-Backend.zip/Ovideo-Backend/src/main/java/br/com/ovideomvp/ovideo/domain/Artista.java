package br.com.ovideomvp.ovideo.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.com.ovideomvp.ovideo.domain.enums.Perfil;
import br.com.ovideomvp.ovideo.dto.ArtistaDTO;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Document(collection = "Artista")
@ToString @Getter @Setter @NoArgsConstructor
public class Artista implements Serializable{
	private static final long serialVersionUID = -4592046558564078263L;
	
	
	@Id
	private String id;
	
	private String nomeArtista;
	private String categoriaArtista;
	private String email;
	
	@JsonIgnore
	private String senha;
	private BigDecimal valor;
	private String urlVideoPrincipal;
	private List<String> urlVideos = new ArrayList<>();
	private String urlFotoCard;
	private String descricaoPrincipal;
	private Double recomendacoes;
	private Date tempoReposta;
	
	@JsonIgnore
	private Integer agencia;
	
	@JsonIgnore
	private Integer conta;
	
	@JsonIgnore
	private Byte digito;
	
	private Set<Integer> perfis =new HashSet<>();;

	
	
	public Artista mapear(ArtistaDTO objDTO) {
		Artista obj = new Artista();
		if(objDTO.getNomeArtista() != null)
			obj.setNomeArtista(objDTO.getNomeArtista());
		if(objDTO.getAgencia() != null)
			obj.setAgencia(objDTO.getAgencia());
		if(objDTO.getCategoriaArtista() != null)
			obj.setCategoriaArtista(objDTO.getCategoriaArtista());
		if(objDTO.getConta() != null)
			obj.setConta(objDTO.getConta());
		if(objDTO.getDescricaoPrincipal() != null)
			obj.setDescricaoPrincipal(objDTO.getDescricaoPrincipal());
		if(objDTO.getDigito() != null)
			obj.setDigito(objDTO.getDigito());
		if(objDTO.getEmail() != null)
			obj.setEmail(objDTO.getEmail());
		if(objDTO.getRecomendacoes() != null)
			obj.setRecomendacoes(objDTO.getRecomendacoes());
			
		if(objDTO.getTempoReposta() != null)
			obj.setTempoReposta(objDTO.getTempoReposta());
		if(objDTO.getUrlFotoCard() != null)
			obj.setUrlFotoCard(objDTO.getUrlFotoCard());
		if(objDTO.getUrlVideoPrincipal() != null)
			obj.setUrlVideoPrincipal (objDTO.getUrlVideoPrincipal());
		if(objDTO.getValor() != null)
			obj.setValor(objDTO.getValor());
		if (objDTO.getUrlVideos() != null && !objDTO.getUrlVideos().isEmpty())
			obj.setUrlVideos(objDTO.getUrlVideos());
		if (objDTO.getId() != null ) {
			obj.setId(objDTO.getId());
		}

		obj.addPerfil(Perfil.ARTISTA);

		return obj;
	}

	public ArtistaDTO DTO() {
		ArtistaDTO objDTO = new ArtistaDTO();
		objDTO.setId(id);
		objDTO.setAgencia(agencia);
		objDTO.setCategoriaArtista(categoriaArtista);
		objDTO.setConta(conta);
		objDTO.setDescricaoPrincipal(descricaoPrincipal);
		objDTO.setDigito(digito);
		objDTO.setEmail(email);
		objDTO.setValor(valor);
		objDTO.setNomeArtista(nomeArtista);
		objDTO.setRecomendacoes(recomendacoes);
		objDTO.setTempoReposta(tempoReposta);
		objDTO.setUrlFotoCard(urlFotoCard);
		objDTO.setUrlVideoPrincipal(urlVideoPrincipal);
		objDTO.setUrlVideos(urlVideos);
		
		return objDTO;
	}

	public void addPerfil(Perfil perfil) {
			perfis.add(perfil.getCod());
		
	}
	public Set<Perfil> getPerfis() {
		return perfis.stream().map(x -> Perfil.toEnum(x)).collect(Collectors.toSet());
	}

	public Artista(String nomeArtista, String categoriaArtista, String email) {
		super();
		this.nomeArtista = nomeArtista;
		this.categoriaArtista = categoriaArtista;
		this.email = email;
	}
}
