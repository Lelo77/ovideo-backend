package br.com.ovideomvp.ovideo.dto;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString @NoArgsConstructor
public class ArtistaDTO implements Serializable{
	private static final long serialVersionUID = 2053558705238629540L;
	
	private String id;
	
	@NotEmpty
	@NotNull
	@Size(min = 3, max = 60)
	private String nomeArtista;
	
	@NotEmpty
	@NotNull
	@Size(min = 3, max = 60)
	private String categoriaArtista;
	
	@Size(min = 7, max = 100)
	private String email;
	
	@Size(min = 7, max = 100)
	private String senha;
	
	private BigDecimal valor;
	private String urlVideoPrincipal;
	private List<String> urlVideos;
	private String urlFotoCard;
	private String descricaoPrincipal;
	private Double recomendacoes;
	private Date tempoReposta;
	private Integer agencia;
	private Integer conta;
	private Byte digito;

}
