package br.com.ovideomvp.ovideo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.ovideomvp.ovideo.domain.Usuario;
import br.com.ovideomvp.ovideo.repository.UsuarioRepository;

@Service
public class UsuarioService extends GenericService<Usuario>{

	
	@Autowired
	public UsuarioService(UsuarioRepository repo) {
		super(repo);
		// TODO Auto-generated constructor stub
	}

	
	



}
