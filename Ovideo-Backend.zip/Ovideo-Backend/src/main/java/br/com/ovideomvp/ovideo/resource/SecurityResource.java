package br.com.ovideomvp.ovideo.resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.ovideomvp.ovideo.security.JWTUtil;
import br.com.ovideomvp.ovideo.service.UserDetailsServiceImpl;
import io.swagger.annotations.Api;

@RestController
@RequestMapping("/security")
@Api
public class SecurityResource extends GenericResource {

	@Autowired
	JWTUtil jwtUtil;
	
	@Autowired
	UserDetailsServiceImpl userDetail;
	
	@PostMapping
	public ResponseEntity<?> validaToken(@RequestParam(value="token") String token){
		if(jwtUtil.tokenValido(token))
			return retornarSucesso(true);
		return retornarErro401(false);
	}
	
	@PostMapping("/obter-perfil")
	public ResponseEntity<?> validaToken2(@RequestParam(value="token") String token){
		
		if(jwtUtil.tokenValido(token)) {
			String email = jwtUtil.getUsername(token);
			UserDetails user = userDetail.loadUserByUsername(email);
			
			System.out.println("AUTORIZAÇÕES: " + user.getAuthorities());
			return retornarSucesso(userDetail.loadUserByUsername(email).getAuthorities());
		}
		
		return retornarErro401(false);
	}
	
}
