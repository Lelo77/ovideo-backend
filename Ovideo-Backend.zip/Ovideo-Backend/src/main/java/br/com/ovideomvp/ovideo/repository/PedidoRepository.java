package br.com.ovideomvp.ovideo.repository;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import br.com.ovideomvp.ovideo.domain.Pedido;

@Repository
public interface PedidoRepository extends MongoRepository<Pedido, String> {
	public List<Pedido> findByIdArtista(String id);
	public Pedido findByIdUsuario(String id);
	public List<Pedido> findByDtPedido(Date date);
	public Pedido findByIdAndIdArtista(String idPedido, String id);
}
