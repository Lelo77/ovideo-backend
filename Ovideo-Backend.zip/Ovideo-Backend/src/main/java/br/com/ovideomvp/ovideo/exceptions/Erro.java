package br.com.ovideomvp.ovideo.exceptions;

import java.io.Serializable;

public class Erro implements Serializable{
	private static final long serialVersionUID = 737697641750503481L;

	private String mensagem;
	private transient Object detalhe;

	public Erro() {
		this(null, null);
	}

	public Erro(final String mensagem, final Object detalhe) {
		super();
		this.mensagem = mensagem;
		this.detalhe = detalhe;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(final String mensagem) {
		this.mensagem = mensagem;
	}

	public Object getDetalhe() {
		return detalhe;
	}

	public void setDetalhe(final Object detalhe) {
		this.detalhe = detalhe;
	}

	@Override
	public String toString() {
		return String.format("UltronErro [mensagem=%s, detalhe=%s]", mensagem, detalhe);
	}
}
