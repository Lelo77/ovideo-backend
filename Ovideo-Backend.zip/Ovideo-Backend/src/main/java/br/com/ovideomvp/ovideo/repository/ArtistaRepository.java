package br.com.ovideomvp.ovideo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import br.com.ovideomvp.ovideo.domain.Artista;

@Repository
public interface ArtistaRepository extends MongoRepository<Artista, String>{

	public Artista findByNomeArtistaAndCategoriaArtistaIgnoreCase(String nomeArtista, String categoriaArtista);
	

	public List<Artista> findAllOrderByValor();
	
	
	public List<Artista> findAllOrderByRecomendacoes();
	

	public List<Artista> findByNomeArtistaIgnoreCase(String nomeArtista);


	public List<Artista> findByCategoriaArtistaIgnoreCase(String categoria);

	public List<Artista> findByNomeArtistaContainingIgnoreCase(String text);
	
	public Artista findByEmail(String email);

}
