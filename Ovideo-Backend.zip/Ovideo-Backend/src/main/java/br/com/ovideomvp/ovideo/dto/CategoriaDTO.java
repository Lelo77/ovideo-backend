package br.com.ovideomvp.ovideo.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString @NoArgsConstructor
public class CategoriaDTO implements Serializable{
	private static final long serialVersionUID = -5356480715103075368L;
	
	private String nome;
	private Long quantidade;
	
	public CategoriaDTO(String nome, Long quantidade) {
		super();
		this.nome = nome;
		this.quantidade = quantidade;
	}
	
	
	
	
}
