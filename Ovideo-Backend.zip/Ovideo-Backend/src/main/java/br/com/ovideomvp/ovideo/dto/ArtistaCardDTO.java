package br.com.ovideomvp.ovideo.dto;

public class ArtistaCardDTO {

}
