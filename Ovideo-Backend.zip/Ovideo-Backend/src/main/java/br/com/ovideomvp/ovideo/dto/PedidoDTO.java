package br.com.ovideomvp.ovideo.dto;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import br.com.ovideomvp.ovideo.domain.enums.StatusPedido;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString @NoArgsConstructor
public class PedidoDTO implements Serializable {
	private static final long serialVersionUID = -9167517011603477927L;
	
	@NotEmpty 
	@NotNull
	@NotBlank
	private String idArtista;
	
	@NotEmpty 
	@NotNull
	@NotBlank
	private String idUsuario;
	
	@NotEmpty 
	@NotNull
	@NotBlank
	private String destinatario;

	@NotEmpty 
	@NotNull
	@NotBlank
	private String conteudoVideo;

	@JsonIgnore
	private String dtPedido;
	
	private StatusPedido status;

	public PedidoDTO(@NotEmpty @NotNull @NotBlank String idArtista, @NotEmpty @NotNull @NotBlank String idUsuario,
			@NotEmpty @NotNull @NotBlank String destinatario, @NotEmpty @NotNull @NotBlank String conteudoVideo,
			String dtPedido, StatusPedido status) {
		super();
		this.idArtista = idArtista;
		this.idUsuario = idUsuario;
		this.destinatario = destinatario;
		this.conteudoVideo = conteudoVideo;
		this.dtPedido = dtPedido;
		this.status = status;
	}

	

	
	
	
	
	
}
