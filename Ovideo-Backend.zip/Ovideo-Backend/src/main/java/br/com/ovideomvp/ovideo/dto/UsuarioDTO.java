package br.com.ovideomvp.ovideo.dto;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter @Setter @ToString @NoArgsConstructor
public class UsuarioDTO implements Serializable{
	private static final long serialVersionUID = 3784961870588320647L;

	@NotEmpty
	@NotNull
	private String email;

	@NotEmpty
	@NotNull
	private String senha;
	
	public UsuarioDTO(String email, String senha) {
		super();
		this.email = email;
		this.senha = senha;
	}
	
	
	
}
