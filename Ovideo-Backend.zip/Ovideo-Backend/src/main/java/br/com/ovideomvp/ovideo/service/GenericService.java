package br.com.ovideomvp.ovideo.service;

import java.net.URI;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.web.multipart.MultipartFile;

import com.amazonaws.services.licensemanager.model.AuthorizationException;

import br.com.ovideomvp.ovideo.domain.enums.Perfil;
import br.com.ovideomvp.ovideo.exceptions.BadRequestException;
import br.com.ovideomvp.ovideo.exceptions.FileException;
import br.com.ovideomvp.ovideo.security.UserSS;

public class GenericService<T> {
	
	@Autowired
	private S3Service s3Service;
	
	MongoRepository<T, String> repo;

	public GenericService(MongoRepository<T, String> repo) {
		this.repo = repo;
	}

	public List<T> findAll() {
		return repo.findAll();
	}

	public T findById(String id) {
//		UserSS user = UserService.authenticated();
//		if (user==null || !user.hasRole(Perfil.ADMIN) && !id.equals(user.getId())) {
//			return null;
//		}
		return repo.findById(id).orElse(null);
	}

	public T save(T entity) {
		return repo.save(entity);
	}

	public T update(T entity, String id) {
		return repo.save(entity);
	}
	
	public T updateCat(T entity) {
		return repo.save(entity);
	}

	public boolean delete(String id) {
		UserSS user = UserService.authenticated();
		if (user==null || !user.hasRole(Perfil.ADMIN) && !id.equals(user.getId())) {
			throw new AuthorizationException("Acesso negado");
		}
		Optional<T> entity = repo.findById(id);
			try {
				Throwable e = null;
				T obj = entity.orElseThrow(() -> new BadRequestException("Não foi possível excluir o objeto", e.getCause()));
				repo.delete(obj);
				return true;
			} catch (BadRequestException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}


		return false;
	}
	
	public URI uploadProfilePicture(MultipartFile file) throws FileException {
		return s3Service.uploadFile(file);
		
	}

	
}
