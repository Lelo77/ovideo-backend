package br.com.ovideomvp.ovideo.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import br.com.ovideomvp.ovideo.domain.Categoria;

@Repository
public interface CategoriaRepository extends MongoRepository<Categoria, String>{

	Categoria findByNomeIgnoreCase(String nome);

	
}
