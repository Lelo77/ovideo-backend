package br.com.ovideomvp.ovideo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.com.ovideomvp.ovideo.domain.Categoria;
import br.com.ovideomvp.ovideo.repository.CategoriaRepository;

@Service
public class CategoriaService extends GenericService<Categoria>{

	@Autowired
	CategoriaRepository repo;
	
	@Autowired
	public CategoriaService(CategoriaRepository repo) {
		super(repo);
	
	}

	public Categoria findByNome(String categoriaArtista) {
		return repo.findByNomeIgnoreCase(categoriaArtista);
	
	}

}
