package br.com.ovideomvp.ovideo.exceptions;

public class BadRequestException extends OvideoException{
	public BadRequestException(String mensagem, Throwable causa) {
		super(mensagem, causa);
		// TODO Auto-generated constructor stub
	}

	private static final long serialVersionUID = 1L;
	
	



}
