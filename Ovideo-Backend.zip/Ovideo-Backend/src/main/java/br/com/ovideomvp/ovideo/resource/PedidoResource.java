//package br.com.ovideomvp.ovideo.resource;
//
//import java.net.MalformedURLException;
//import java.net.URI;
//import java.util.List;
//import java.util.Optional;
//import java.util.stream.Collectors;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.web.bind.annotation.GetMapping;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RequestParam;
//import org.springframework.web.bind.annotation.RestController;
//import org.springframework.web.multipart.MultipartFile;
//
//import com.amazonaws.services.apigatewayv2.model.BadRequestException;
//import com.amazonaws.services.licensemanager.model.AuthorizationException;
//import com.amazonaws.services.mediapackagevod.model.NotFoundException;
//
//import br.com.ovideomvp.ovideo.domain.Artista;
//import br.com.ovideomvp.ovideo.domain.Pedido;
//import br.com.ovideomvp.ovideo.domain.Usuario;
//import br.com.ovideomvp.ovideo.domain.enums.Perfil;
//import br.com.ovideomvp.ovideo.domain.enums.StatusPedido;
//import br.com.ovideomvp.ovideo.dto.PedidoDTO;
//import br.com.ovideomvp.ovideo.dto.PedidoTableDTO;
//import br.com.ovideomvp.ovideo.exceptions.FileException;
//import br.com.ovideomvp.ovideo.repository.PedidoRepository;
//import br.com.ovideomvp.ovideo.security.JWTUtil;
//import br.com.ovideomvp.ovideo.security.UserSS;
//import br.com.ovideomvp.ovideo.service.ArtistaService;
//import br.com.ovideomvp.ovideo.service.EmailPedidoService;
//import br.com.ovideomvp.ovideo.service.PedidoService;
//import br.com.ovideomvp.ovideo.service.UserDetailsServiceImpl;
//import br.com.ovideomvp.ovideo.service.UserService;
//import br.com.ovideomvp.ovideo.service.UsuarioService;
//import io.swagger.annotations.Api;
//
//@RestController
//@RequestMapping("/pedidos")
//@Api
//public class PedidoResource extends GenericResource {
//
//	@Autowired
//	PedidoService pedidoService;
//
//	@Autowired
//	PedidoRepository pedidoRepository;
//
//	@Autowired
//	ArtistaService artistaService;
//
//	@Autowired
//	UsuarioService UsuarioService;
//	
//	@Autowired
//	UserDetailsServiceImpl userDetails;
//	
//	@Autowired
//	JWTUtil jwt;
//	
//	@Autowired
//	EmailPedidoService<Pedido> emailService;
//	
////	@Autowired
////	AbstractEmailServiceEntregaPedido emailEntregaPedido;
//	
////	@Autowired
////	AbstractEmailServicePedido emailPedido;
//
//	@PostMapping("/salvar")
//	public ResponseEntity<String> salvar(@RequestBody PedidoDTO pedidoDto) {
//		UserSS user = UserService.authenticated();
//		
////		if (user==null || !user.hasRole(Perfil.ADMIN) && !pedidoDto.getIdUsuario().equals(user.getId()) || 
////				pedidoDto.getIdArtista().equals(user.getId())) {
////			throw new AuthorizationException("Acesso negado");
////		}
//		
//		Artista artista = artistaService.findById(pedidoDto.getIdArtista());
//		Usuario usuario = UsuarioService.findById(user.getId());
//
//		if (artista != null && usuario != null) {
//			Pedido p = pedidoService.prepararPedido(pedidoDto, artista.getId(), usuario.getId());
//			p = pedidoService.save(p);
//			
//			String status = pedidoService.enviarDadosPagSeguro(p, usuario.getEmail(), artista);
//			
//			//p.setUrlFinalizarCompra(status);
//			pedidoService.update(p,p.getId());
//			emailService.sendOrderConfirmationHtmlEmail(p);
//			
//			return retornarCriado(status);
//			//return retornarCriado("sucesso");
//
//		}
//		
//		return retornarErro(null);
//	}
//	
//	@GetMapping("/consultar-pedido")
//	public ResponseEntity<Pedido> obterPedido(@RequestParam(value="id_Pedido") String idPedido, @RequestParam(value="id_user") String idUsuario ){
//			Optional<Pedido> pedido = pedidoRepository.findById(idPedido);			
//			return retornarSucesso(pedido.orElseThrow(()->new NotFoundException("O pedido Não foi encontrado")));
//	}
//	
//	@GetMapping("/")
//	public ResponseEntity<List<PedidoTableDTO>> listar(){
//		UserSS user = UserService.authenticated();
//		if (user==null || !user.hasRole(Perfil.ADMIN) || !user.hasRole(Perfil.ARTISTA)) {
//			throw new AuthorizationException("Acesso negado");
//		}
//		
//		List<Pedido> lspedidos = pedidoRepository.findByIdArtista(user.getId());
//		
//		List<PedidoTableDTO> pedidos = (lspedidos.stream().map(x -> {
//			return new PedidoTableDTO(x.getId(), x.getDestinatario(), x.getStatus(), x.getConteudoVideo());
//		}).collect(Collectors.toList()));
//		
//		return retornarSucesso(pedidos);
//	}
//	
//	@PostMapping(value = "/send-video")
//	public ResponseEntity<String> uploadVideo(@RequestParam(name = "file") MultipartFile file,
//											@RequestParam(name="idArtista") String id,
//											@RequestParam(name="idPedido") String idPedido)throws MalformedURLException {
//		URI uri;
//		try {
//			UserSS user = UserService.authenticated();
//			if (user==null || !user.hasRole(Perfil.ADMIN) && !id.equals(user.getId())) {
//				throw new AuthorizationException("Acesso negado");
//			}
//			
//			Pedido p = pedidoRepository.findByIdAndIdArtista(idPedido, id);
//			Usuario usuario = UsuarioService.findById(p.getIdUsuario());
//			
//			if(p != null && usuario != null) {
//				uri = pedidoService.uploadProfilePicture(file);	
//				usuario.getUrlVideo().add(uri.toURL().toString());
//				emailService.sendOrderConfirmationHtmlEmailEntregaPedido(p);
//			//	emailEntregaPedido.sendOrderConfirmationHtmlEmail(p);
//				p.setStatus(StatusPedido.ENTREGUE.getDescricao());
//				pedidoService.update(p, idPedido);
//				UsuarioService.update(usuario, id);
//				return retornarSucesso("Video Entregue com sucesso");
//			}
//		} catch (FileException e) {
//			new BadRequestException("Não foi possível fazer o upload do arquivo");
//			e.printStackTrace();
//		}
//		return retornarErro(null);
//	}
//	
//	
//	
//}
