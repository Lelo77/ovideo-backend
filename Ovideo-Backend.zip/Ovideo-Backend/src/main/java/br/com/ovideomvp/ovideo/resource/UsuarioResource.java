package br.com.ovideomvp.ovideo.resource;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import br.com.ovideomvp.ovideo.domain.Usuario;
import br.com.ovideomvp.ovideo.domain.enums.Perfil;
import br.com.ovideomvp.ovideo.dto.CredenciaisDTO;
import br.com.ovideomvp.ovideo.dto.UsuarioDTODetalhes;
import br.com.ovideomvp.ovideo.repository.UsuarioRepository;
import br.com.ovideomvp.ovideo.service.UsuarioService;

@RestController
@RequestMapping("/usuarios")
public class UsuarioResource extends GenericResource{

	@Autowired
	UsuarioRepository usuarioRepository;
	
	@Autowired
	UsuarioService usuarioService;
	
	@Autowired
	BCryptPasswordEncoder pe;
	
	@PostMapping("/criar")
	public ResponseEntity<Usuario> criar(@RequestParam(value="email")String email, @RequestParam(value="senha") String senha){
		Usuario usuario = usuarioRepository.findByEmail(email);
		if(usuario != null) {
			return retornarErro(null);
		}
		usuario = new Usuario(email, pe.encode(senha));
		usuario.addPerfil(Perfil.CLIENTE);
		return retornarCriado(usuarioRepository.save(usuario));
	}
	
	
	
	@PutMapping("/alterar")
	public ResponseEntity<Usuario> alterar(UsuarioDTODetalhes objDTO){
		Usuario user = usuarioRepository.findByEmail(objDTO.getEmail());
	
		if(user == null)
			return retornarErro(null);
		
		user.PreencherDetalhes(objDTO);
		
		return retornarSucesso(usuarioService.update(user,user.getId()));	
		
	}
	
	@DeleteMapping("/delete")
	public ResponseEntity<?> delete(CredenciaisDTO credenciais){
		try {
			Usuario user = usuarioRepository.findByEmail(credenciais.getEmail());
			usuarioService.delete(user.getId());
			return retornarSucesso(null);
		} catch (Exception e) {
			return retornarErro(null);
		}
	}
	
	@GetMapping("/")
	public ResponseEntity<List<Usuario>> findall(){
		return retornarSucesso(usuarioService.findAll());
	}
	
	@GetMapping("/buscar")
	public ResponseEntity<Usuario> findById(@RequestParam("id")String id){
		Usuario user = usuarioService.findById(id);
		if(user != null)
			return retornarSucesso(user);
		return retornarNaoEncontrado();
	}
}
