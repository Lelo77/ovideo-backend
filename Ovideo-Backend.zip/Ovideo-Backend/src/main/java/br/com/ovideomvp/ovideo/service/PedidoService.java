package br.com.ovideomvp.ovideo.service;

import java.text.SimpleDateFormat;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Service;

import br.com.ovideomvp.ovideo.domain.Artista;
import br.com.ovideomvp.ovideo.domain.Pedido;
import br.com.ovideomvp.ovideo.domain.enums.StatusPedido;
import br.com.ovideomvp.ovideo.dto.PedidoDTO;
import br.com.ovideomvp.ovideo.repository.PedidoRepository;
import br.com.uol.pagseguro.domain.AccountCredentials;
import br.com.uol.pagseguro.domain.Credentials;
import br.com.uol.pagseguro.domain.Item;
import br.com.uol.pagseguro.domain.PaymentRequest;
import br.com.uol.pagseguro.domain.Sender;
import br.com.uol.pagseguro.enums.Currency;
import br.com.uol.pagseguro.exception.PagSeguroServiceException;


@Service
public class PedidoService extends GenericService<Pedido> {

	@Autowired
	PedidoRepository pedidoRepository;
	
	
	
	
	public PedidoService(MongoRepository<Pedido, String> repo) {
		super(repo);
		// TODO Auto-generated constructor stub
	}
	

	public Pedido prepararPedido(PedidoDTO pedidoDto, String idArtista, String idUsuario) {
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		
		String destinatario = pedidoDto.getDestinatario();
		sdf.format(new Date());
		
		//Pedido pedido = new Pedido(null, idArtista, idUsuario,idUsuario, pedidoDto.getConteudoVideo(), sdf.format(new Date()), destinatario, destinatario);
		
		Pedido pedido = new Pedido(null, idArtista, idUsuario, destinatario, pedidoDto.getConteudoVideo(), sdf.format(new Date()), StatusPedido.PENDENTE.getDescricao());
		
		
		return pedido;
		
	}


	public String enviarDadosPagSeguro(Pedido p, String username, Artista artista) {
		try {
			PaymentRequest request = new PaymentRequest();
			request.setReference(p.getId());
			request.setCurrency(Currency.BRL);
			request.setSender(getSender());
			request.addItem(getItem(artista,p));
			request.setNotificationURL("google.com");
			request.setRedirectURL("google.com");
			
			return request.register(getCredentials());
		} catch (PagSeguroServiceException e) {
			e.printStackTrace();
		}
		return null;
	}
	public Sender getSender(){
		Sender sender = new Sender();
		sender.setName("Rodrigo Yuri de Jesus Cordeiro");
		sender.setEmail("rodrigoyuri2@hotmail.com");

		
		return sender;
		
	}
	
	
	public Item getItem(Artista artista, Pedido p) {
		Item item = new Item();
		item.setAmount(artista.getValor());
		item.setDescription("O vídeo da sua celebridade favorita");
		item.setId(p.getId());
		item.setQuantity(1);
		
		return item;
	}
	
	public Credentials getCredentials() throws PagSeguroServiceException {
		return new AccountCredentials("rodrigoyuri2@hotmail.com", "650b7d5c-9e0e-412d-a23c-271e9b4a8df6af32ca7649aa99e096ab2e7a8db705869314-a042-4588-91ff-076e0a3b753e");
	}
}

