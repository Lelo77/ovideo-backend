package br.com.ovideomvp.ovideo.dto;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
public class UsuarioDTODetalhes implements Serializable {
	private static final long serialVersionUID = 6786427810764475359L;

	@NotEmpty
	@NotNull
	private String email;
	
	@NotEmpty
	@NotNull
	private String nrCartao;
	@NotEmpty
	@NotNull
	private Integer codSeguranca;
	
	private String urlFotoPerfil;
	
	private String celular;

	public UsuarioDTODetalhes(String nrCartao, Integer codSeguranca, String urlFotoPerfil, String celular) {
		super();
		this.nrCartao = nrCartao;
		this.codSeguranca = codSeguranca;
		this.urlFotoPerfil = urlFotoPerfil;
		this.celular = celular;
	}

}
