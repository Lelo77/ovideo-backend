package br.com.ovideomvp.ovideo.service;

import java.util.Date;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import br.com.ovideomvp.ovideo.domain.Pedido;
import br.com.ovideomvp.ovideo.domain.Usuario;

public abstract class AbstractEmailServicePedido implements EmailPedidoService<Pedido> {
	
	@Value("${default.sender}")
	private String sender;
	
	@Autowired
	private TemplateEngine templateEngine;
	
	@Autowired
	private JavaMailSender javaMailSender;
	
	@Autowired
	private UsuarioService service;
	
	//NÃO USAR
	@Override
	public void sendConfirmacaoPedido(Pedido obj) {
		SimpleMailMessage sm = prepareSimpleMailMessageFromPedido(obj);
		sendEmail(sm);
	}
	
	//NAO USAR
	protected SimpleMailMessage prepareSimpleMailMessageFromPedido(Pedido obj) {
		SimpleMailMessage sm = new SimpleMailMessage();
		
		Usuario user = service.findById(obj.getId());
		
		sm.setTo(user.getEmail());
		sm.setFrom(sender);
		sm.setSubject("Pedido confirmado! Código: " + obj.getId());
		sm.setSentDate(new Date(System.currentTimeMillis()));
		sm.setText(obj.toString());
		return sm;
	}
	
	protected String htmlFromTemplateCadastro(Pedido obj) {
		Context context = new Context();
		context.setVariable("pedido", obj);
		return templateEngine.process("email/confirmacao-compra", context);
	}
	protected String htmlFromTemplateEntrega(Pedido obj) {
		Context context = new Context();
		context.setVariable("pedido", obj);
		return templateEngine.process("email/entregaPedido", context);
	}
	
	@Override
	public void sendOrderConfirmationHtmlEmail(Pedido obj) {
		try {
			MimeMessage mm = prepareMimeMessageFromPedido(obj);
			sendHtmlEmail(mm);
		}
		catch (MessagingException e) {
			sendConfirmacaoPedido(obj);
		}
	}

	protected MimeMessage prepareMimeMessageFromPedido(Pedido obj) throws MessagingException {
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		MimeMessageHelper mmh = new MimeMessageHelper(mimeMessage, true);
		Usuario user = service.findById(obj.getIdUsuario());
		
		mmh.setTo(user.getEmail());
		mmh.setFrom(sender);
		mmh.setSubject("Ovideo: Pedido Realizado com Sucesso!");
		mmh.setSentDate(new Date(System.currentTimeMillis()));
		mmh.setText(htmlFromTemplateCadastro(obj), true);
		return mimeMessage;
	}
	
	@Override
	public void sendOrderConfirmationHtmlEmailEntregaPedido(Pedido obj) {
		try {
			MimeMessage mm = prepareMimeMessageFromEntregaPedido(obj);
			sendHtmlEmail(mm);
		}
		catch (MessagingException e) {
			sendConfirmacaoPedido(obj);
		}
	}

	protected MimeMessage prepareMimeMessageFromEntregaPedido(Pedido obj) throws MessagingException {
		MimeMessage mimeMessage = javaMailSender.createMimeMessage();
		MimeMessageHelper mmh = new MimeMessageHelper(mimeMessage, true);
		Usuario user = service.findById(obj.getIdUsuario());
		
		mmh.setTo(user.getEmail());
		mmh.setFrom(sender);
		mmh.setSubject("Ovideo: Seu vídeo está Pronto!");
		mmh.setSentDate(new Date(System.currentTimeMillis()));
		mmh.setText(htmlFromTemplateEntrega(obj), true);
		return mimeMessage;
	}
	
	
}
