package br.com.ovideomvp.ovideo.mappers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Component;

import br.com.ovideomvp.ovideo.domain.Artista;
import br.com.ovideomvp.ovideo.domain.enums.Perfil;
import br.com.ovideomvp.ovideo.dto.ArtistaDTO;

@Component
public class ArtistaMapper {
	
	@Autowired
	BCryptPasswordEncoder pe;
	
	public Artista mapear(ArtistaDTO objDto) {
		Artista obj = new Artista();
		
		obj.setAgencia(objDto.getAgencia());
		obj.setCategoriaArtista(objDto.getCategoriaArtista());
		obj.setConta(objDto.getConta());
		obj.setDescricaoPrincipal(objDto.getDescricaoPrincipal());
		obj.setDigito(objDto.getDigito());
		obj.setEmail(objDto.getEmail());
		obj.setNomeArtista(objDto.getNomeArtista());
		obj.addPerfil(Perfil.ARTISTA);
		obj.addPerfil(Perfil.CLIENTE);
		obj.setSenha(pe.encode(objDto.getSenha()));
		obj.setTempoReposta(objDto.getTempoReposta());
		obj.setValor(objDto.getValor());
		
		return obj;
	
	}
}
