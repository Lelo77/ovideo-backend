package br.com.ovideomvp.ovideo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import br.com.ovideomvp.ovideo.domain.Artista;
import br.com.ovideomvp.ovideo.domain.Usuario;
import br.com.ovideomvp.ovideo.repository.ArtistaRepository;
import br.com.ovideomvp.ovideo.repository.UsuarioRepository;
import br.com.ovideomvp.ovideo.security.UserSS;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {

	@Autowired
	private ArtistaRepository artistaRepository;
	
	@Autowired
	private UsuarioRepository usuarioRepository;
	
	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		Artista artista = artistaRepository.findByEmail(email);
		Usuario usuario = usuarioRepository.findByEmail(email);
		
		if (artista != null) {
			return new UserSS(artista.getId(),artista.getEmail(),artista.getSenha(), artista.getPerfis());
			
		}
		else if(usuario != null) {
			return new UserSS(usuario.getId(), usuario.getEmail(), usuario.getSenha(), usuario.getPerfis());

		}else {
			throw new UsernameNotFoundException(email);
		}
	}
}
