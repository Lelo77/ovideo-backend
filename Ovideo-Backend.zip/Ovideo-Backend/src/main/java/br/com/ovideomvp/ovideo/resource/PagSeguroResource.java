//package br.com.ovideomvp.ovideo.resource;
//
//import java.math.BigDecimal;
//import java.util.Currency;
//
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.ResponseBody;
//import org.springframework.web.bind.annotation.RestController;
//
//import br.com.uol.pagseguro.domain.AccountCredentials;
//import br.com.uol.pagseguro.domain.Credentials;
//import br.com.uol.pagseguro.domain.Item;
//import br.com.uol.pagseguro.domain.PaymentRequest;
//import br.com.uol.pagseguro.domain.Sender;
//import br.com.uol.pagseguro.exception.PagSeguroServiceException;
//import io.swagger.annotations.Api;
//
//@RestController
//@Api
//@RequestMapping("/pagseguro")
//public class PagSeguroResource {
//	private final String token = "650b7d5c-9e0e-412d-a23c-271e9b4a8df6af32ca7649aa99e096ab2e7a8db705869314-a042-4588-91ff-076e0a3b753e";
//	private final String email = "rodrigoyuri2@hotmail.com";
//	
//	@PostMapping(value="/pagseguro-criarpagamento")
//	public @ResponseBody String criarPagamento() {
//		try {
//			PaymentRequest request = new PaymentRequest();
//			request.setReference("pedidoid");
//			request.setCurrency();
//			request.setSender(getSender());
//			request.addItem(getItem());
//			request.setNotificationURL("google.com");
//			request.setRedirectURL("google.com");
//			
//			return request.register(getCredentials());
//		} catch (PagSeguroServiceException e) {
//			e.printStackTrace();
//		}
//		return null;
//	}
//	
//	public Sender getSender(){
//		Destinatario d = new Destinatario();
//		d.setName("Rodrigo Yuri de Jesus Cordeiro");
//		d.setEmail(email);
//
//		
//		return d;
//		
//	}
//	
//	
//	public Item getItem() {
//		Item item = new Item();
//		item.setAmount(new BigDecimal("10.00"));
//		item.setDescription("Ovideo");
//		item.setId("12");
//		item.setQuantity(1);
//		
//		return item;
//	}
//	
//	public Credentials getCredentials() throws PagSeguroServiceException {
//		return new AccountCredentials(email, token);
//	}
//}
