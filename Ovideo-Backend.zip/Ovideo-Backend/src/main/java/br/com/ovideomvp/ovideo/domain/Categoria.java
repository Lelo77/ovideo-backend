package br.com.ovideomvp.ovideo.domain;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import br.com.ovideomvp.ovideo.dto.CategoriaDTO;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@Document(collection="Categoria")
@Getter @Setter @ToString
public class Categoria {

	@Id
	private String id;
	private String nome;
	private Long quantidade;
	
	public CategoriaDTO DTO(Categoria categoria) {
		CategoriaDTO obj = new CategoriaDTO();
		obj.setNome(categoria.getNome());
		obj.setQuantidade(categoria.getQuantidade());
		return obj;
	}
	
	public Categoria mapear(CategoriaDTO categoriaDTO) {
		Categoria cat = new Categoria();
		cat.setNome(categoriaDTO.getNome());
		cat.setQuantidade(categoriaDTO.getQuantidade());
		return cat;
	}
}
