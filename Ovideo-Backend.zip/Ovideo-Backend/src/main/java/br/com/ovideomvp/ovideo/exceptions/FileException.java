package br.com.ovideomvp.ovideo.exceptions;

public class FileException extends OvideoException{
	private static final long serialVersionUID = -5108643323527252874L;

	public FileException(String mensagem, Object detalhe) {
		super(mensagem, detalhe);
		
	}

}
