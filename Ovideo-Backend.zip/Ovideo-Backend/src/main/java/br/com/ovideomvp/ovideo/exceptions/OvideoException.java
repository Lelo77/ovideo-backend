package br.com.ovideomvp.ovideo.exceptions;

public class OvideoException extends Exception{
	private static final long serialVersionUID = 1L;

	private final Erro erro;
	
	public OvideoException(final String mensagem, final Throwable causa) {
		super(mensagem, causa);
		erro = new Erro(mensagem, causa.getStackTrace());
	}

	public OvideoException(final String mensagem) {
		this(mensagem, mensagem);
	}

	public OvideoException(final String mensagem, final Object detalhe) {
		super(mensagem);
		erro = new Erro(mensagem, detalhe);
	}

	public Erro getErro() {
		return erro;
	}

	@Override
	public String toString() {
		return String.format("UltronException [erro=%s]", erro);
	}
}
